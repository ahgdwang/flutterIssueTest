import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'lottie_widget.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or press Run > Flutter Hot Reload in a Flutter IDE). Notice that the
        // counter didn't reset back to zero; the application is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: MyHomePage(title: 'Flutter Demo Home Page'),
    );
  }
}

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key, this.title}) : super(key: key);

  // This widget is the home page of your application. It is stateful, meaning
  // that it has a State object (defined below) that contains fields that affect
  // how it looks.

  // This class is the configuration for the state. It holds the values (in this
  // case the title) provided by the parent (in this case the App widget) and
  // used by the build method of the State. Fields in a Widget subclass are
  // always marked "final".

  final String title;

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {

  MethodChannel _channel;
  int viewId=0;
  String viewType;

  EventChannel eventChannel = const EventChannel('com.ahgdwang.FlutterVC');
  StreamSubscription _subscription;

  @override
  void initState() {
    super.initState();
    _subscription = eventChannel.receiveBroadcastStream().listen(_onEvent,onError: _onError);
  }

  @override
  void dispose() {
    super.dispose();
    _subscription.cancel();
    _subscription = null;
  }


    // 回调事件
  void _onEvent(Object event) {
    setState(() {
      viewType = event.toString();
    });
  }
  // 错误返回
  void _onError(Object error) {

  }

  @override
  Widget build(BuildContext context) {
    // This method is rerun every time setState is called, for instance as done
    // by the _incrementCounter method above.
    //
    // The Flutter framework has been optimized to make rerunning build methods
    // fast, so that you can just rebuild anything that needs updating rather
    // than having to individually change instances of widgets.
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(0),
          child: AppBar(
              brightness: Brightness.light,
              elevation: 0,
              backgroundColor: Colors.transparent)),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Expanded(
            child:body(),
          ),
        ],

      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  Widget body() {
    if (viewType == 'FlutterLottiePlatFormSmallAnimVC') {
      return Stack(
        children: <Widget>[
          Center(child:Container(width: 100,height: 100,child:
            Stack(
              alignment: Alignment.center,
              children: <Widget>[
                Center(child: LottieWidget(filePath: 'lottie/LottieSmall/bg_voice_speaking/data.json', width: 100, height: 100,autoPlay: true,loop:true)),
                Center(child: LottieWidget(filePath: 'lottie/LottieSmall/icon_voice_speaking/data.json', width: 50, height: 50,autoPlay: true,loop:true)),
              ],
            ))),
            Align(
              alignment: Alignment.bottomRight,
              child: FlatButton(onPressed: onTap, child: Icon(Icons.add)),
            )
          ],
      );
    } 
    else {
      return SizedBox();
    }
  }

  void onTap() {
    showModalBottomSheet(
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (builder) {
      return SizedBox(
        height:100,
        child: Container(
            decoration: new BoxDecoration(
              color: Colors.white,
            ),
            child: Container(),
        ),
      );
    }, context: context);
  }
}
