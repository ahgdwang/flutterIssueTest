import 'dart:ffi';

import 'package:flutter/widgets.dart';
import 'package:flutter_lottie/flutter_lottie.dart';
import 'dart:async';
import 'package:lottie/lottie.dart';
import 'dart:io' as io;

// ignore: must_be_immutable
class LottieWidget extends StatefulWidget {
  final String filePath;
  final bool autoPlay;
  final bool loop;
  final double width;
  final double height;

  LottieWidget({
    Key key,
    @required final this.filePath,
    this.autoPlay,
    this.loop,
    @required this.width,
    @required this.height
  }) : super(key: key ?? ValueKey((filePath ?? filePath) + '_lottie')) {
    if (this.filePath == null) {
      throw Exception('filePath is null!');
    }
  }

  @override
  _LottieWidgetState createState() => _LottieWidgetState(this.filePath,this.autoPlay,this.loop,this.width,this.height);
}

class _LottieWidgetState extends State<LottieWidget> {
  String filePath;
  bool autoPlay;
  bool loop;
  double width;
  double height;

  LottieController controller;
  LottieController controller2;
  StreamController<double> newProgressStream;

  @override
  void initState() {
    super.initState();
    newProgressStream = new StreamController<double>();
  }

  _LottieWidgetState(this.filePath,this.autoPlay,this.loop,this.width,this.height);

  @override
  void dispose() {
    super.dispose();
    newProgressStream.close();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width,
      height: height,
      child: io.Platform.isIOS ?
      LottieView.fromFile(
        filePath:filePath,
        autoPlay: autoPlay,
        loop: loop,
        onViewCreated: onViewCreatedFile,
      ) : Lottie.asset(
          filePath,
          repeat: loop,
        ),
    );
  }
  void onViewCreatedFile(LottieController controller) {
    this.controller2 = controller;
    newProgressStream.stream.listen((double progress) {
      this.controller2.setAnimationProgress(progress);
    });
  }
}
