//
//  SceneDelegate.h
//  flutterAniTest
//
//  Created by ahgdwang on 2020/7/27.
//  ahgdwang.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

