//
//  AppDelegate.h
//  flutterAniTest
//
//  Created by ahgdwang on 2020/7/27.
//  ahgdwang.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (strong, nonatomic) UIWindow * window;
@end

