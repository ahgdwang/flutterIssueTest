//
//  FlutterLottieBigAnimVC.h
//  flutterAniTest
//
//  Created by honghewang on 2020/7/28.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FlutterLottiePlatFormSmallAnimVC : UIViewController

@end

NS_ASSUME_NONNULL_END
