//
//  FlutterLottieBigAnimVC.m
//  flutterAniTest
//
//  Created by honghewang on 2020/7/28.
//

#import "FlutterLottiePlatFormSmallAnimVC.h"
#import <Flutter/Flutter.h>
#import <FlutterPluginRegistrant/GeneratedPluginRegistrant.h>

@interface FlutterLottiePlatFormSmallAnimVC ()<FlutterStreamHandler>

@property (nonatomic, strong) FlutterViewController *flutterVC;
@property (nonatomic, strong) FlutterEventChannel *eventChannel;

@end

@implementation FlutterLottiePlatFormSmallAnimVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.flutterVC = [[FlutterViewController alloc] init];
    [self addChildViewController:self.flutterVC];
    [self.view addSubview:self.flutterVC.view];
    self.flutterVC.view.frame = self.view.bounds;
    
    self.eventChannel = [FlutterEventChannel eventChannelWithName:@"com.ahgdwang.FlutterVC" binaryMessenger:self.flutterVC.binaryMessenger];
    //设置消息处理器的代理
    [self.eventChannel setStreamHandler:self];
    [GeneratedPluginRegistrant registerWithRegistry:self.flutterVC.engine];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self.eventChannel setStreamHandler:nil];
}

- (void)dealloc {
    [_flutterVC.engine destroyContext];
}

#pragma mark - <FlutterStreamHandler>
- (FlutterError* _Nullable)onListenWithArguments:(id _Nullable)arguments
                                       eventSink:(FlutterEventSink)events {
    if (events) {
        events(@"FlutterLottiePlatFormSmallAnimVC");
    }
    return nil;
}

- (FlutterError* _Nullable)onCancelWithArguments:(id _Nullable)arguments {
    NSLog(@"%@", arguments);
    return nil;
}

@end
